import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

import os
import sys
import json
import datetime
from datetime import date
from dateutil import parser

from sailthru.sailthru_client import SailthruClient
from sailthru.sailthru_response import SailthruResponseError
from sailthru.sailthru_error import SailthruClientError

import boto
import boto.s3

from secrets import *
from boto.s3.connection import OrdinaryCallingFormat, S3Connection

api_key = ST_API_KEY
api_secret = ST_API_SECRET
sailthru_client = SailthruClient(api_key, api_secret)

def get_last_blast_id(newsletter):
    try:
            response = sailthru_client.api_get("blast", {"blast": "blast data" , "list": newsletter, "status": "sent"})

            if response.is_ok():
                try:
                     body = response.get_body()
                     blast_data = body
                     blast_ids_list = []
                     start_times = []
                     usable_dates = []
                     for blast in blast_data['blasts']:
                         blast_ids_list.append(blast['blast_id'])
                         start_times.append(blast['start_time'])
                     for time in start_times:
                         time_list = time.split()
                         year = time_list[3]
                         month = time_list[2]
                         day = time_list[1]
                         if month == 'Jan':
                             numerical_month = '01'
                         elif month == 'Feb':
                             numerical_month = '02'
                         elif month == 'Mar':
                             numerical_month = '03'
                         elif month == 'Apr':
                             numerical_month = '04'
                         elif month == 'May':
                             numerical_month = '05'
                         elif month == 'Jun':
                             numerical_month = '06'
                         elif month == 'Jul':
                             numerical_month = '07'
                         elif month == 'Aug':
                             numerical_month = '08'
                         elif month == 'Sep':
                             numerical_month = '09'
                         elif month == 'Oct':
                             numerical_month = '10'
                         elif month == 'Nov':
                             numerical_month = '11'
                         else:
                             numerical_month = '12'
                         new_date = year + '/' + numerical_month + '/' + day
                         usable_dates.append(new_date)
                     blast_dates = zip(blast_ids_list,usable_dates)
                     return blast_dates

                except:
                    print "API call was good but there was a problem cleaning the data."
            else:
                print "There was a problem with the API call for " + newsletter
                error = response.get_error()
                print ("Error: " + error.get_message())
                print ("Status Code: " + str(response.get_status_code()))
                print ("Error Code: " + str(error.get_error_code()))

    except SailthruClientError as e:
        # Handle exceptions
        print ("Exception")
        print (e)


def get_last_week_date(newsletter, blast_dates):
    try:
        if (newsletter == 'newsletter_axiosam'):
            last_week = blast_dates[8][1]
        elif (newsletter == 'newsletter_axiossneakpeek'):
            last_week = blast_dates[1][1]
        else:
            last_week = blast_dates[6][1]

        return last_week

    except Exception, e:
        print e
        print "Problem calculating date for one week prior to last send"


def get_last_week_date_range():
    try:
        #CHANGE THIS BACK TO TODAY AND NOT YESTERDAY IF RUNNING OVERNIGHT ON CRON
        #str_today = str(datetime.date.today())
        #parsed_today =  parser.parse(str_today)
        today = datetime.date.today()
        yesterday =  str(datetime.datetime.strptime(str(today), '%Y-%m-%d') + datetime.timedelta(days=-1))
        last_week_range = str(datetime.datetime.strptime(str(yesterday), '%Y-%m-%d %H:%M:%S') + datetime.timedelta(days=-6))
        last_week_range_dates = [last_week_range, str(yesterday)]
        return last_week_range_dates

    except Exception, e:
        print e
        print "Problem calculating date for previous week date range"


def get_second_week_date_range(last_week_range_dates):
    try:
        last_day_previous_week = last_week_range_dates[0]
        first_day_two_weeks = str(datetime.datetime.strptime(str(last_day_previous_week), '%Y-%m-%d %H:%M:%S') + datetime.timedelta(days=-1))

        last_day_two_weeks = str(datetime.datetime.strptime(str(first_day_two_weeks), '%Y-%m-%d %H:%M:%S') + datetime.timedelta(days=-6))

        two_weeks_range_dates = [last_day_two_weeks,first_day_two_weeks]

        return two_weeks_range_dates

    except Exception, e:
        print "Problem getting second week date range"
        print e


def blast_data_last_send(newsletter, last_blast):
    try:
        response = sailthru_client.api_get("stats", {"stat": "blast" , "list": newsletter, "start_date": last_blast, "end_date": last_blast})

        if response.is_ok():
            try:
                body = response.get_body()
                last_blast_data = body
                return last_blast_data

            except:
                print "API call was good but there was a problem cleaning the data."
        else:
            print "There was a problem with the API call for " + newsletter
            error = response.get_error()
            print ("Error: " + error.get_message())
            print ("Status Code: " + str(response.get_status_code()))
            print ("Error Code: " + str(error.get_error_code()))

    except SailthruClientError as e:
        # Handle exceptions
        print ("Exception")
        print (e)


def blast_data_last_week(newsletter, last_week_date):
    try:
        response = sailthru_client.api_get("stats", {"stat": "blast" , "list": newsletter, "start_date": last_week_date, "end_date": last_week_date})

        if response.is_ok():
            try:
                body = response.get_body()
                last_week_blast = body
                return last_week_blast

            except:
                print "API call was good but there was a problem cleaning the data."
        else:
            print "There was a problem with the API call for " + newsletter
            error = response.get_error()
            print ("Error: " + error.get_message())
            print ("Status Code: " + str(response.get_status_code()))
            print ("Error Code: " + str(error.get_error_code()))

    except SailthruClientError as e:
        # Handle exceptions
        print ("Exception")
        print (e)


def blast_last_week_average(newsletter, start_last_week_range, end_last_week_range):
    try:
            #long term want to automate these dates
            response = sailthru_client.api_get("stats", {"stat": "blast" , "list": newsletter, "start_date": start_last_week_range , "end_date": end_last_week_range})

            if response.is_ok():
                try:
                     body = response.get_body()
                     blast_data_last_week = body
                     #print blast_data_last_week
                     return blast_data_last_week

                except:
                    print "API call was good but there was a problem cleaning the data."
            else:
                print "There was a problem with the API call for " + newsletter
                error = response.get_error()
                print ("Error: " + error.get_message())
                print ("Status Code: " + str(response.get_status_code()))
                print ("Error Code: " + str(error.get_error_code()))

    except SailthruClientError as e:
        # Handle exceptions
        print ("Exception")
        print (e)


def blast_second_week_average(newsletter, start_second_week_range, end_second_week_range):
    try:
            #long term want to automate these dates
            response = sailthru_client.api_get("stats", {"stat": "blast" , "list": newsletter, "start_date": start_second_week_range , "end_date": end_second_week_range})

            if response.is_ok():
                try:
                     body = response.get_body()
                     blast_data_second_week = body
                     #print blast_data_second_week
                     return blast_data_second_week

                except:
                    print "API call was good but there was a problem cleaning the data."
            else:
                print "There was a problem with the API call for " + newsletter
                error = response.get_error()
                print ("Error: " + error.get_message())
                print ("Status Code: " + str(response.get_status_code()))
                print ("Error Code: " + str(error.get_error_code()))

    except SailthruClientError as e:
        # Handle exceptions
        print ("Exception")
        print (e)


def clean_json(newsletter, average_last_week, average_two_weeks_ago, last_blast_data, last_week_blast):
    try:
        print "Attempting to clean up JSON data..."

        #NL count last week calculation
        if (newsletter == 'newsletter_axiossneakpeek'):
            average_newsletters_sent = average_last_week['count']
        elif (newsletter == 'newsletter_axiosam'):
            average_newsletters_sent = float(average_last_week['count']) / float(7)
        elif (newsletter == 'newsletter_axiosvitals'):
            average_newsletters_sent = float(average_last_week['count']) / float(3)
        else:
            average_newsletters_sent = float(average_last_week['count']) / float(5)

        #NL count two weeks ago calculation
        if (newsletter == 'newsletter_axiossneakpeek'):
            average_newsletters_sent_2 = average_two_weeks_ago['count']
        elif (newsletter == 'newsletter_axiosam'):
            average_newsletters_sent_2 = float(average_two_weeks_ago['count']) / float(7)
        else:
            average_newsletters_sent_2 = float(average_two_weeks_ago['count']) / float(5)

        #average open rate calculation
        average_open_rate =  float(average_last_week['estopens']) / float(average_last_week['count'])

        #average opens two weeks ago calculation
        average_open_rate_two_weeks_ago = float(average_two_weeks_ago['estopens']) / float(average_two_weeks_ago['count'])

        #CTR last week caluclation
        CTR_last_week = float(average_last_week['click_total']) / float(average_last_week['count'])

        #CTR two weeks ago calculation
        CTR_two_weeks_ago = float(average_two_weeks_ago['click_total']) / float(average_two_weeks_ago['count'])

        cleaned_json = {
            newsletter + '-total_sends_last_week': average_last_week['count'],
            newsletter + '-total_sends_two_weeks_ago': average_two_weeks_ago['count'],
            newsletter + '-email_count_average': average_newsletters_sent,
            newsletter + '-email_count_last_week_average': average_newsletters_sent_2,
            newsletter + '-ctr_last_week': CTR_last_week,
            newsletter + '-ctr_two_weeks_ago': CTR_two_weeks_ago,
            newsletter + '-average_open_rate' : average_open_rate,
            newsletter + '-average_open_rate_two_weeks_ago': average_open_rate_two_weeks_ago,
            newsletter + '-count_end_of_last_week': last_blast_data['count'],
            newsletter + '-count_end_of_two_weeks_ago': last_week_blast['count']

        }

        print "Success!"
        #print cleaned_json

        return cleaned_json
    except Exception, e:
        print "Error cleaning up JSON"
        print e


def create_json_file(all_data):

    flattened_data = {}
    for newsletter in all_data:
        for key, value in newsletter.iteritems():
            flattened_data[key] = value
    return flattened_data
    """
    try:
        print "Attempting to create JSON file..."

        with open('sailthru-weekly-cache.json', 'w') as outfile:
            json.dump(flattened_data, outfile)
        print "Created json file"
    except Exception, e:
        print "Error creating JSON file"
        print e


def upload_file_to_s3():
    try:
        conn = S3Connection(AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, calling_format=OrdinaryCallingFormat())
        bucket = conn.get_bucket('axios-analytics-data')
        filename = 'sailthru-weekly-cache.json'
        k = boto.s3.key.Key(bucket)
        k.key = 'sailthru-weekly-cache.json'
        k.set_contents_from_filename(filename)
        # check that file exists
        # then do the push to S3 stuff
        # huzzah, everything went perfectly?
        print 'Uploaded file to s3'
    except Exception, e:
        print "Error uploading file to S3"
        print e
    """

def upload_file_to_s3(flattened_data):
    try:
        conn = S3Connection(AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, calling_format=OrdinaryCallingFormat())
        bucket = conn.get_bucket('axios-analytics-data')
        filename = 'sailthru-weekly-cache.json'
        k = boto.s3.key.Key(bucket)
        k.key = filename
        k.set_metadata('Content-Type', 'application/json')
        k.set_contents_from_string(json.dumps(flattened_data))
        # check that file exists
        # then do the push to S3 stuff
        # huzzah, everything went perfectly?
    except Exception, e:
        print "Error uploading file to S3"
        print e

def main():
    try:
        newsletters = ['newsletter_axiosam', 'newsletter_axiosprorata', 'newsletter_axiosvitals', 'newsletter_axiossneakpeek', 'newsletter_axiosgenerate', 'newsletter_axioslogin']

        all_data = []

        for i in range(0,len(newsletters)):

            newsletter = newsletters[i]
            blast_dates = get_last_blast_id(newsletter)
            last_week_date = get_last_week_date(newsletter, blast_dates)
            if (newsletter == 'newsletter_axiossneakpeek'):
                last_blast = blast_dates[0][1]
            else:
                last_blast = blast_dates[1][1]
            last_week_range_dates = get_last_week_date_range()
            start_last_week_range = last_week_range_dates[0]
            end_last_week_range = last_week_range_dates[1]
            last_blast_data = blast_data_last_send(newsletter, last_blast)
            last_week_blast = blast_data_last_week(newsletter, last_week_date)



            second_week_range_dates = get_second_week_date_range(last_week_range_dates)
            start_second_week_range = second_week_range_dates[0]
            end_second_week_range = second_week_range_dates[1]

            average_last_week = blast_last_week_average(newsletter, start_last_week_range, end_last_week_range)
            average_two_weeks_ago = blast_second_week_average(newsletter, start_second_week_range, end_second_week_range)

            cleaned_json = clean_json(newsletter, average_last_week, average_two_weeks_ago, last_blast_data, last_week_blast)
            all_data.append(cleaned_json)

        flattened_data = create_json_file(all_data)
        upload_file_to_s3(flattened_data)

    except Exception, e:
        print "Error exchanging data in main function"
        print e

def handle(event, context):
    main()
    print "Everything went smoothly! Hooray."

#main()
